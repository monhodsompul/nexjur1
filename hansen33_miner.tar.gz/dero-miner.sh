/data/data/com.termux/files/home/storage/downloads/hansen33_miner/hansen33s-dero-miner-linux-amd64 --wallet-address=s --daemon-rpc-address=community-pools.mysrv.cloud:10300
